Project Tasks allow to record the time spent on them, but some activities
often require you to keep a record of the material used also.

This module offers the ability to keep track of that material.

Note that only a simple record is made and no accounting or stock moves are
actually performed.
