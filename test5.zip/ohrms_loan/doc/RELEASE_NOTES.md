## Module <ohrms_loan>

#### 21.04.2018
#### Version 12.0.1.0.0
##### ADD
- Initial commit for Open HRMS Project

#### 08/11/2018
#### Version 12.0.1.0.1
##### FIX
- Fixed TypeError Git Issue #13

#### 12/12/2018
#### Version 12.0.1.0.1
##### CHANGE
- Exception class changed
- State visibility changed
- Restriction added for deletion

