Open HRMS Employee Checklist
---------------------
Supporting Addon for Open HRMS, Manages Employee's Entry & Exit Process

Overview
--------
A well functioning human resource department will lay down a number procedure and process before an employee during joining/resigning time. It may be submission/Return of a certificate or attending a conference etc.
A person has to undergo all these checklist items before being admitted/resigned. The module simplifies the process by providing you a checklist to mark the proceedings. It will also display the PercentPie of the checklist items completed.

Connect with experts
--------------------

If you have any question/queries/additional works on OpenHRMS or this module, You can drop an email directly to Cybrosys.

Contacts
--------
info - info@cybrosys.com
Nilmar Shereef - odoo@cybrosys.com
Kavya Raveendran - v12 

Website:
https://www.openhrms.com
https://www.cybrosys.com
